from switchyard.lib.userlib import *

scenario = TestScenario("test example")
